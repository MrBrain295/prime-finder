# Prime Finder

Credit to: <a href="https://rosettacode.org/wiki/Strong_and_weak_primes#Python">Rosettacode</a>, <a href="https://realpython.com/python-timer/">Real Python</a>.
Rossetacode's python script fixed up, with a timer and user input instead of preset values. <p><b>REQUIRES NumPy.</b></p>
